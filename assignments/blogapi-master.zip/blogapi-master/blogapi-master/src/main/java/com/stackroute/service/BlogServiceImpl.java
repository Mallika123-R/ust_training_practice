package com.stackroute.service;


import com.stackroute.domain.Blog;
import com.stackroute.repository.BlogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/* Add annotation to declare this class as Service class.
 * Also it should implement BlogService Interface and override all the implemented methods.*/
@Service
public class BlogServiceImpl implements BlogService {

    @Autowired
    private BlogRepository repository;

    @Override

    public Blog saveBlog(Blog blog) {
        return repository.save(blog);
    }

    @Override

    public List<Blog> getAllBlogs() {
        List<Blog> all = repository.findAll();

        return all;
    }

    @Override
    public Blog getBlogById(int id) {
        Optional<Blog> blog = repository.findById(id);
        if (blog.isPresent()) {
            return blog.get();
        }
        return null;
    }

    @Override
    public Blog deleteBlog(int id) {

        Optional <Blog> existingBlog = repository.findById(id);
        if (existingBlog.isPresent()) {
              Blog blog= repository.findById(id).get();
              repository.deleteById(id);
            return blog;
        }
        return null;

    }
    @Override
    public Blog updateBlog(Blog blog) {

           Optional <Blog> existingBlog = repository.findById(blog.getBlogId());
             if(existingBlog.isPresent())
             {
                Blog blog1=repository.findById(blog.getBlogId()).get();
               blog1.setBlogTitle(blog.getBlogTitle());
                blog1.setAuthorName(blog.getAuthorName());
                blog1.setBlogContent(blog.getBlogContent());
                repository.save(blog1);
                return blog1;
            }
                 return null;

    }
}
