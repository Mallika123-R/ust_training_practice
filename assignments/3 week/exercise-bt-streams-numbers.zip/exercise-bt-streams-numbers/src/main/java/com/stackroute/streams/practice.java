package com.stackroute.streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class practice {

    public static void main(String[] args)
    {
        List<Integer> list= Arrays.asList(3, 6, 5, 9, 12);
       // list.forEach(x->System.out.println(x));

        list.stream()
                .filter(no->no%2==0)
                .map(no->
                {
                    no%2!=0;
                })

                .forEach(System.out::println)



    }
}
